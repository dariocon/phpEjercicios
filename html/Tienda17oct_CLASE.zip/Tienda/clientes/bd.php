<?php
if (!isset($_SESSION['data'])) {
    $_SESSION['data'] = 
 [
    [
        'id' => 1,
        'name' => 'Merola',
        'surname' => 'Arnely',
        'email' => 'marnely0@icq.com',
        'gender' => 'Female',
        'address' => 'Room 817'
    ],
    [
        'id' => 2,
        'name' => 'Lucius',
        'surname' => 'Morena',
        'email' => 'lmorena1@rambler.ru',
        'gender' => 'Male',
        'address' => 'PO Box 22439'
    ],
    [
        'id' => 3,
        'name' => 'Natal',
        'surname' => 'Ragless',
        'email' => 'nragless2@edublogs.org',
        'gender' => 'Male',
        'address' => 'Suite 68'
    ],
    [
        'id' => 4,
        'name' => 'Kelli',
        'surname' => 'Juniper',
        'email' => 'kjuniper3@php.net',
        'gender' => 'Female',
        'address' => 'PO Box 13305'
    ],
    [
        'id' => 5,
        'name' => 'Marje',
        'surname' => 'Stollenbecker',
        'email' => 'mstollenbecker4@cbsnews.com',
        'gender' => 'Female',
        'address' => '10th Floor'
    ],
    [
        'id' => 6,
        'name' => 'Bethina',
        'surname' => 'Lansdowne',
        'email' => 'blansdowne5@mysql.com',
        'gender' => 'Female',
        'address' => 'Suite 67'
    ],
    [
        'id' => 7,
        'name' => 'Hans',
        'surname' => 'Artz',
        'email' => 'hartz6@ehow.com',
        'gender' => 'Male',
        'address' => 'Suite 14'
    ],
    [
        'id' => 8,
        'name' => 'Cayla',
        'surname' => 'Denney',
        'email' => 'cdenney7@latimes.com',
        'gender' => 'Female',
        'address' => 'Room 470'
    ],
    [
        'id' => 9,
        'name' => 'Cece',
        'surname' => 'Tamburo',
        'email' => 'ctamburo8@imdb.com',
        'gender' => 'Male',
        'address' => 'PO Box 24214'
    ],
    [
        'id' => 10,
        'name' => 'Goraud',
        'surname' => 'Bolver',
        'email' => 'gbolver9@mashable.com',
        'gender' => 'Male',
        'address' => 'PO Box 93595'
    ],
    [
        'id' => 11,
        'name' => 'Biddy',
        'surname' => 'Barwis',
        'email' => 'bbarwisa@storify.com',
        'gender' => 'Female',
        'address' => 'Apt 546'
    ],
    [
        'id' => 12,
        'name' => 'Garey',
        'surname' => 'Caesman',
        'email' => 'gcaesmanb@prweb.com',
        'gender' => 'Male',
        'address' => 'PO Box 14886'
    ],
    [
        'id' => 13,
        'name' => 'Heall',
        'surname' => 'Budge',
        'email' => 'hbudgec@dmoz.org',
        'gender' => 'Male',
        'address' => '16th Floor'
    ],
    [
        'id' => 14,
        'name' => 'Pincus',
        'surname' => 'Haslin',
        'email' => 'phaslind@printfriendly.com',
        'gender' => 'Male',
        'address' => 'Room 692'
    ],
    [
        'id' => 15,
        'name' => 'Fayth',
        'surname' => 'Tarquinio',
        'email' => 'ftarquinioe@delicious.com',
        'gender' => 'Female',
        'address' => 'Room 1616'
    ],
    [
        'id' => 16,
        'name' => 'Vinny',
        'surname' => 'Skey',
        'email' => 'vskeyf@facebook.com',
        'gender' => 'Male',
        'address' => 'Apt 1484'
    ]
    ];
}
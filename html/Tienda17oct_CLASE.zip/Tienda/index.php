<?php
    require "header.php";

?>  
    <main class="container">
        <div class="container mt-5">

            <h1>Bienvenido a mi tienda</h1>
            <h1></h1>



        </div>

    </main>

<?php
    require "footer.php"

?>